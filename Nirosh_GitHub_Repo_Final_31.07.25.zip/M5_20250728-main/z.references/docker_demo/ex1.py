from calculator_app import Calculator

cal = Calculator(364,7)

print(cal.do_product())